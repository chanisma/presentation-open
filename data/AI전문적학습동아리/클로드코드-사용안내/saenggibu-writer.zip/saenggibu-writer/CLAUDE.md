# 생기부 생성 엔진 (saenggibu-writer)

고등학교 **생활기록부 과목별 세부능력 및 특기사항(세특)·평가문**을 학생 자료로부터 작성하는 파이프라인 엔진.
학생의 보고서(pdf)·자기평가(xlsx)·hwpx 등을 하나의 Excel로 정리하고, 과목 프롬프트에 따라 학생별 평가문을 **NLP로 작성**한 뒤, NEIS 바이트 수를 계산하고, 표형 HTML 검수본과 교과세특 업로드 xlsx를 만든다.

> 실제 작성 로직·단계별 규칙·품질 가드레일은 **`saenggibu-writer` 스킬**에 있다. 평가문 작업을 시작할 때 이 스킬을 반드시 사용한다. 이 문서는 그 위의 프로젝트 지도(구조·출력·명령어)다.

## 핵심 원칙
- **평가문은 NLP로 쓴다.** 자료를 읽고 이해해 사람이 쓰듯 작성한다. 규칙·템플릿 문자열 치환으로 문장을 찍어내지 않는다.
- **자료에 충실.** 보고서·코드에서 실제 확인되는 사실만 근거로 쓴다. 인터넷 검색·추측 금지, 학생 문장 복붙 금지.
- **스크립트는 결정적인 일만.** 바이트 계산, Excel/HTML 조립, NEIS 양식 채우기 등만 파이썬이 맡는다.
- **분량은 눈대중 금지.** NEIS 바이트 규칙(한글 3 / 엔터 2 / 그 외 1)을 `byte_count.py`로 측정한다.
- **스킬 스크립트는 공용 — 수정 금지.** 특정 과목에만 필요한 기능은 스킬 `scripts/`를 고치지 말고, 그 과목의 `results/<연도>_<과목>/`에 전용 변형 스크립트(예: `build_html_주목.py`)를 만들어 적용한다. 공용 수정은 모든 과목에 이로운 범용 개선일 때만.

## 프로젝트 구조
```
E:\saenggibu-writer\
├── CLAUDE.md                     # 이 문서
├── prompts/                      # ★ 과목 맞춤 프롬프트 (작업 폴더 기준)
│   └── <과목>.prompt.txt         #   기본 프롬프트를 과목에 맞게 적응한 것 (2단계에서 저장·재사용)
├── results/                      # ★ 모든 산출물 (작업 폴더 기준)
│   └── <연도>_<과목>/            #   연도_과목 폴더 하나에 중간·최종 산출물이 모임 (예: 2026_정보)
│       ├── students.json         #   중간 데이터 (3단계 생성 → 4단계 채움)
│       ├── 결과.xlsx             #   통합 검수 Excel
│       ├── 결과.html             #   표형 검수 HTML
│       └── <업로드>.xlsx         #   교과세특 업로드 양식 (NEIS 채움 또는 새 양식)
└── .claude/skills/saenggibu-writer/   # 엔진(스킬) 본체 — 코드·양식만 담는다
    ├── SKILL.md                  # 파이프라인 전체 지침 (5단계)
    ├── scripts/                  # 결정적 처리 스크립트 (아래 표)
    ├── assets/
    │   ├── default_prompt.txt    # 기본 프롬프트 (사용자 txt·과목 프롬프트 없을 때)
    │   └── 교과기초자료_양식.xlsx  # 업로드 기준 양식 (헤더: 학번·이름·교과세특·성적)
    └── references/
        ├── memory/               # 과목 누적 지시 (프롬프트 본문은 여기 두지 않음)
        │   ├── INDEX.md          # 과목별 MEMORY 운영 규칙 + 목록
        │   └── <과목>.md         # 과목별 누적 지시 (+ prompts/<과목>.prompt.txt 포인터)
        └── quality-skills/       # 품질 보정 번들 (grammar-checker·humanizer·style-guide)
```

**저장 위치 규칙**
- **프롬프트 본문**(`.prompt.txt`)은 작업 폴더 `prompts/`에, **과목 누적 지시**(`.md`)는 스킬 안 `references/memory/`에 나뉘어 있다.
- **중간·최종 산출물은 모두** 작업 폴더의 `results/<연도>_<과목>/`(예: `results/2026_정보/`) 한 폴더에 모은다. 스킬 폴더 안에는 산출물을 쓰지 않는다.
- `prompts/`·`results/`는 **현재 작업 디렉토리 기준 상대경로**다.

## 파이프라인 (5단계)
1. **기초 정보 수집** — 과목명·제공 자료·프롬프트 경로·성적/제약사항·NEIS 양식 유무·**대상 연도**. `references/memory/<과목>.md`와 `prompts/<과목>.prompt.txt`(있으면)를 읽는다.
2. **프롬프트 준비** — 우선순위: ① 사용자 txt → ② `prompts/<과목>.prompt.txt` → ③ `assets/default_prompt.txt`를 과목에 맞게 적응 후 `prompts/<과목>.prompt.txt`로 저장.
3. **학생 자료 처리 → 통합 Excel** — 흩어진 자료를 `students.json`으로 모으고 `build_workbook.py`로 Excel 생성. (이 시점 평가문 열은 비어 있음)
4. **평가문 작성(NLP) + 품질 보정 + 바이트 검증** — 학생별로 역량 선정→근거 서술→**품질 보정(grammar-checker·humanizer·style-guide)**→`byte_count.py`로 분량 확인. **쉼표 점검(`comma_check.py`)은 품질 보정의 필수 단계** — 연결어미 뒤 쉼표를 0으로(측정, 눈대중 금지).
   - **쉼표·가운뎃점 점검(`comma_check.py`)은 품질 보정의 필수 단계** — 연결어미 뒤 쉼표와 가운뎃점(·)을 모두 0으로(가운뎃점은 '와/과'·쉼표·풀어쓰기로 대체, 인공지능 흔적 제거). 또 **default→과목 프롬프트 적응 시 작성 규칙을 하나도 빠뜨리지 않는다**(적응·추가만, 삭제 금지).
   - **4.5 별도 검토 패스 (quality-skills 단계 · 사용자 확인 후 실행)** — 배치 작성 후, 자기승인을 피해 **독립 서브에이전트**가 세 품질 스킬을 `Skill` 도구로 **실제 호출**(문서만 읽지 않음; humanizer는 40패턴 S1/S2/S3 분석)해 문법·자연스러움·반 전체 일관성을 검토한다. 토큰이 드므로 **먼저 사용자에게 묻고** 실행하며, 반영 시 원문→수정 **변경 내역을 `results/<연도>_<과목>/품질수정_변경내역.md`로 저장**하고 `students.json`에 `평가문_초안`(원문)을 보존한다. 상세·프롬프트: `${SKILL}/references/quality-skills/README.md`·`review-pass.md`.
5. **검수 HTML + 교과세특 업로드 xlsx** — 표형 HTML(`build_html.py`) + 업로드 양식(`build_gwagi.py`, NEIS 채우기/새 양식 자동 판별).

## 출력 방식
- **중간 데이터: `students.json`** — 모든 스크립트가 공유하는 단일 표현. `{ "subject", "students":[{번호, 이름, 성적, 제약사항, 활동:{활동명:내용}, 목표바이트, 평가문, 바이트수}] }`.
- **검수 Excel(`결과.xlsx`)** — 활동별 열 + 평가문 + 바이트/판정 색상.
- **검수 HTML(`결과.html`)** — **표형 단일 뷰.** 번호·이름·성적·평가문·바이트·목표·판정(적정/초과/미달)·활동 자료를 한 표에. 열 머리글 클릭 정렬, 검색 필터, 활동 자료 펼치기, 제약사항 경고. 데이터 임베드된 단일 파일.
- **업로드 xlsx** — (A) NEIS 다운로드 양식을 `--template`로 주면 원본 보존하며 세특 칸만 채움(반/번호·이름 매칭). (B) 없으면 평평한 새 양식(학번·이름·교과세특·성적).

## 명령어
`${SKILL}` = `.claude/skills/saenggibu-writer`, `${DIR}` = `results/<연도>_<과목>`(예: `results/2026_정보`)로 바꿔 실행.

```bash
# 3단계 — 통합 검수 Excel
python "${SKILL}/scripts/build_workbook.py" ${DIR}/students.json ${DIR}/결과.xlsx

# 4단계 — 단일 평가문 바이트 측정
python "${SKILL}/scripts/byte_count.py" "작성한 평가문"
# 4단계 — students.json 일괄 바이트 검수(+판정 기록)
python "${SKILL}/scripts/byte_count.py" --json ${DIR}/students.json --write
# 4단계 — 쉼표·가운뎃점 점검(필수): 밀도·연결어미 뒤 쉼표·가운뎃점(·) 나열 측정
python "${SKILL}/scripts/comma_check.py" --json ${DIR}/students.json
# 4단계 — 연결어미 뒤 쉼표 정리(원문은 평가문_초안 보존) → 이후 바이트 재검증
python "${SKILL}/scripts/comma_check.py" --json ${DIR}/students.json --clean --write

# 5단계 — 표형 검수 HTML
python "${SKILL}/scripts/build_html.py" ${DIR}/students.json ${DIR}/결과.html

# 5단계 — 교과세특 업로드 xlsx (NEIS 양식이 있으면 --template로 채우기)
python "${SKILL}/scripts/build_gwagi.py" ${DIR}/students.json ${DIR}/결과_NEIS업로드.xlsx \
  --template "C:/.../2026_1학기_1학년_1_정보_과목세특_1.xlsx"
# 5단계 — NEIS 양식이 없을 때 새 양식
python "${SKILL}/scripts/build_gwagi.py" ${DIR}/students.json ${DIR}/교과기초자료.xlsx \
  --template "${SKILL}/assets/교과기초자료_양식.xlsx"
```

## 스크립트
| 스크립트 | 역할 |
|---|---|
| `byte_count.py` | NEIS 바이트 계산(한글3/엔터2/그외1). 단일 문자열 또는 `--json students.json --write`로 일괄 검수·판정 기록 |
| `comma_check.py` | **쉼표·가운뎃점 점검(필수)**: humanizer 패턴 1(밀도)·3(연결어미 뒤 쉼표) + 가운뎃점(·) 나열 측정. `--clean --write`로 연결어미 뒤 쉼표만 정리(원문은 `평가문_초안` 보존). 가운뎃점은 문맥 판단이 필요해 수동 대체 |
| `build_workbook.py` | `students.json` → 통합 검수 `.xlsx` (활동별 열 + 평가문 + 바이트/판정 색상) |
| `build_html.py` | `students.json` → **표형** 검수 HTML (정렬·검색·활동자료 펼치기·제약사항 경고) |
| `build_gwagi.py` | `students.json` → 업로드 xlsx. `--template`로 NEIS 채우기/새 양식 자동 판별. 반/번호·이름 매칭 + 매칭 리포트 |
| `make_neis_sample.py` | `build_gwagi.py` NEIS 탐지/채우기 로직의 회귀 테스트 픽스처 생성 |

## 자주 하는 실수
- ❌ 평가문을 스크립트/규칙으로 조립 → ✅ 자료를 읽고 NLP로 서술
- ❌ 바이트 눈대중 → ✅ `byte_count.py`로 측정, 목표 벗어나면 다시 씀
- ❌ 쉼표·가운뎃점 점검을 건너뜀·눈대중 → ✅ `comma_check.py`로 필수 측정, 연결어미 뒤 쉼표와 가운뎃점(·)은 0(정리·대체 후 바이트 재검증)
- ❌ 여러 요소를 가운뎃점(·)으로 나열(인공지능 흔적) → ✅ '와/과'·쉼표·풀어쓰기로 잇기
- ❌ default→과목 프롬프트로 옮기며 작성 규칙 누락 → ✅ 규칙은 적응·추가만, 삭제 금지(default와 대조)
- ❌ 보고서 문장 복붙·코드/변수명 노출 → ✅ 사실만 추출·재서술
- ❌ 3단계에서 평가문까지 미리 작성 → ✅ 정리/작성 분리
- ❌ 산출물을 스킬 폴더나 임시 폴더에 저장 → ✅ 작업 폴더 `results/<연도>_<과목>/`에 모으기
- ❌ 프롬프트를 스킬에 박힌 양식으로 덮어씀 → ✅ 이번 프롬프트 규칙을 그대로 따름
- ❌ 과목 하나의 요청으로 스킬 공용 스크립트를 수정 → ✅ 과목 폴더 전용 변형 스크립트로 적용(공용은 그대로)
