#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
students.json  ->  검수용 HTML (표형 + 검색/정렬)

각 학생의 자료(활동별), 평가문, 바이트수/목표/판정을 한 표에서 정렬·검색하며 검수한다.
활동 자료와 제약사항은 표 안에서 펼쳐 볼 수 있어 근거 대조가 가능하다.
데이터는 HTML 안에 JSON으로 임베드되어 단일 파일로 어디서나 열린다.

사용법: python build_html.py students.json 결과.html
"""
import sys
import os
import json
import html as htmllib

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from byte_count import count_bytes, parse_target  # noqa: E402


def enrich(students):
    out = []
    for s in students:
        text = s.get("평가문", "") or ""
        # 저장된 '바이트수'는 쉼표 정리 등으로 평가문이 바뀐 뒤 낡았을 수 있어 항상 재계산한다.
        n = count_bytes(text)
        lo, hi = parse_target(s.get("목표바이트", ""))
        if hi is not None and n > hi:
            status = "over"
        elif lo is not None and n and n < lo:
            status = "under"
        elif text:
            status = "ok"
        else:
            status = "empty"
        out.append({
            "번호": s.get("번호", ""),
            "이름": s.get("이름", ""),
            "성적": s.get("성적", ""),
            "제약사항": s.get("제약사항", ""),
            "활동": s.get("활동", {}) or {},
            "목표바이트": s.get("목표바이트", ""),
            "평가문": text,
            "바이트수": n if text else "",
            "status": status,
        })
    return out


def embed_json(obj) -> str:
    """<script> 안에 안전하게 넣을 JSON 직렬화.

    학생 자료(활동 내용)에 '</script>' 같은 HTML이 들어 있으면 스크립트 태그가
    조기 종료되어 페이지 전체가 깨진다. JSON에서 <, >, &는 문자열 안에서만
    나타나므로 유니코드 이스케이프로 바꿔도 값이 보존된다. U+2028/U+2029는
    구형 JS 파서에서 문자열 리터럴을 깨뜨리므로 함께 이스케이프한다.
    """
    s = json.dumps(obj, ensure_ascii=False)
    for ch, rep in (("&", "\\u0026"), ("<", "\\u003c"), (">", "\\u003e"),
                    ("\u2028", "\\u2028"), ("\u2029", "\\u2029")):
        s = s.replace(ch, rep)
    return s


TEMPLATE = """<!DOCTYPE html>
<html lang="ko"><head><meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>__TITLE__ · 생활기록부 검수</title>
<style>
  :root{--bg:#f6f7f9;--card:#fff;--line:#e6e8eb;--ink:#1f2328;--sub:#6b7280;--accent:#2f5496;}
  *{box-sizing:border-box}
  body{margin:0;height:100vh;height:100dvh;display:flex;flex-direction:column;
       font-family:"Pretendard","맑은 고딕","Malgun Gothic",system-ui,sans-serif;background:var(--bg);color:var(--ink)}
  header{background:var(--accent);color:#fff;padding:14px 20px;box-shadow:0 1px 6px rgba(0,0,0,.15)}
  header h1{margin:0;font-size:18px;font-weight:700}
  header .meta{font-size:13px;opacity:.9;margin-top:2px}
  .toolbar{display:flex;gap:10px;align-items:center;flex-wrap:wrap;padding:12px 20px;background:#fff;border-bottom:1px solid var(--line)}
  .toolbar input{flex:1;min-width:180px;padding:8px 12px;border:1px solid var(--line);border-radius:8px;font-size:14px}
  .wrap{flex:1;min-height:0;display:flex;flex-direction:column;width:100%;max-width:1180px;margin:0 auto;padding:14px 20px 18px}
  .count{font-size:13px;color:var(--sub);margin:0 0 10px}
  .pill{display:inline-block;font-size:12px;font-weight:700;padding:2px 9px;border-radius:999px}
  .ok{background:#d9ead3;color:#274e13}.over{background:#f4cccc;color:#a61b1b}
  .under{background:#fff2cc;color:#7f6000}.empty{background:#eee;color:#888}
  /* 표 — 표 영역이 스크롤 컨테이너라서 머리글이 top:0 으로 항상 고정된다.
     (페이지 스크롤 + 고정 offset 방식은 overflow 래퍼 안에서 sticky가 무력화되어 폐기) */
  .tablewrap{flex:1;min-height:0;overflow:auto;background:#fff;border:1px solid var(--line);border-radius:8px}
  table{width:100%;border-collapse:separate;border-spacing:0;font-size:13.5px}
  th,td{border-bottom:1px solid var(--line);border-right:1px solid var(--line);padding:9px 10px;text-align:left;vertical-align:top}
  th:last-child,td:last-child{border-right:0}
  th{position:sticky;top:0;z-index:2;background:var(--accent);color:#fff;cursor:pointer;white-space:nowrap}
  th.plain{cursor:default}
  td.c{text-align:center;white-space:nowrap}
  td.eval{min-width:360px;line-height:1.7;white-space:pre-wrap}
  tr:nth-child(even) td{background:#fafbfc}
  .constraint{font-size:12.5px;color:#a61b1b;margin-top:6px}
  details{font-size:13px}details summary{cursor:pointer;color:var(--accent);font-weight:600}
  .act{margin:6px 0;padding:8px 10px;background:#f6f7f9;border-radius:6px;min-width:240px;max-width:520px;overflow-wrap:anywhere}
  .act b{display:block;color:var(--accent);margin-bottom:2px;font-size:12.5px}
  .noresult{padding:28px;text-align:center;color:var(--sub)}
  @media print{
    body{display:block;height:auto}
    .toolbar{display:none}
    .wrap{max-width:none}
    .tablewrap{overflow:visible;border:0}
    th{position:static}
  }
</style></head>
<body>
<header><h1>__TITLE__ · 생활기록부 평가문</h1><div class="meta">학생 __N__명 · 열 머리글로 정렬, 검색으로 검수하세요</div></header>
<div class="toolbar">
  <input id="q" placeholder="이름·번호·내용 검색…" oninput="render()">
</div>
<div class="wrap">
  <div class="count" id="count"></div>
  <div class="tablewrap" id="tableView"></div>
</div>
<script>
const DATA = __DATA__;
const esc = s => String(s==null?"":s).replace(/[&<>"]/g,c=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;"}[c]));
const STAT = {ok:"적정",over:"초과",under:"미달",empty:"미작성"};
const RANK = {over:0,under:1,empty:2,ok:3};   // 판정 정렬: 문제 있는 학생부터
const COLS = [["번호","번호"],["이름","이름"],["성적","성적"],[null,"평가문"],
              ["바이트수","바이트"],[null,"목표"],["status","판정"],[null,"활동 자료"]];
function match(s,q){if(!q)return true;q=q.toLowerCase();const hay=[s.번호,s.이름,s.제약사항,s.평가문,JSON.stringify(s.활동)].join(" ").toLowerCase();return hay.includes(q);}
function actsHTML(s){
  const acts=Object.entries(s.활동||{}).map(([k,v])=>`<div class="act"><b>${esc(k)}</b>${esc(v)}</div>`).join("");
  return `<details><summary>보기</summary>${acts||"<div class='act'>자료 없음</div>"}</details>`;
}
function tableHTML(list){
  if(!list.length)return `<div class="noresult">검색 결과가 없습니다</div>`;
  const arrow=k=>sortKey===k?(sortAsc?" ▲":" ▼"):"";
  const ths=COLS.map(([k,label])=>k?`<th onclick="sortBy('${k}')">${label}${arrow(k)}</th>`
                                   :`<th class="plain">${label}</th>`).join("");
  const rows=list.map(s=>{
    const con=s.제약사항?`<div class="constraint">⚠ ${esc(s.제약사항)}</div>`:"";
    const bytes=s.바이트수===""?"":s.바이트수;
    return `<tr><td class="c">${esc(s.번호)}</td><td class="c">${esc(s.이름)}</td><td class="c">${esc(s.성적)}</td>
    <td class="eval">${esc(s.평가문)||"<i style='color:#aaa'>미작성</i>"}${con}</td>
    <td class="c">${bytes}</td><td class="c">${esc(s.목표바이트)}</td>
    <td class="c"><span class="pill ${s.status}">${STAT[s.status]||""}</span></td>
    <td>${actsHTML(s)}</td></tr>`;
  }).join("");
  return `<table><thead><tr>${ths}</tr></thead><tbody>${rows}</tbody></table>`;
}
let sortKey=null,sortAsc=true;
function sortBy(k){if(sortKey===k)sortAsc=!sortAsc;else{sortKey=k;sortAsc=true;}render();}
function render(){
  const q=document.getElementById('q').value;
  let list=DATA.filter(s=>match(s,q));
  if(sortKey){list=[...list].sort((a,b)=>{let x=a[sortKey],y=b[sortKey];
    if(sortKey==="status"){x=RANK[x];y=RANK[y];}
    else if(!isNaN(parseFloat(x))&&!isNaN(parseFloat(y))){x=+x;y=+y;}
    return (x>y?1:x<y?-1:0)*(sortAsc?1:-1);});}
  const n={ok:0,over:0,under:0,empty:0};list.forEach(s=>n[s.status]++);
  document.getElementById('count').textContent=
    `표시: ${list.length}명 · 적정 ${n.ok} · 초과 ${n.over} · 미달 ${n.under} · 미작성 ${n.empty}`;
  document.getElementById('tableView').innerHTML=tableHTML(list);
}
render();
</script>
</body></html>"""


def main():
    if len(sys.argv) < 3:
        sys.exit("사용법: python build_html.py students.json 결과.html")
    src, out = sys.argv[1], sys.argv[2]
    with open(src, encoding="utf-8") as f:
        data = json.load(f)
    students = data.get("students", data if isinstance(data, list) else [])
    subject = data.get("subject", "생활기록부")
    rows = enrich(students)
    html = (TEMPLATE
            .replace("__TITLE__", htmllib.escape(subject))
            .replace("__N__", str(len(rows)))
            .replace("__DATA__", embed_json(rows)))
    with open(out, "w", encoding="utf-8") as f:
        f.write(html)
    print(f"저장 완료: {out}  (학생 {len(rows)}명)")


if __name__ == "__main__":
    main()
